package datastructures;

/**
 * Created by Group 29D on 25-Mar-17.
 */
public class Reviewer {
    private String staffID;
    private String name;


    public String getStaffID() {
        return staffID;
    }

    public void setStaffID(String staffID) {
        this.staffID = staffID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
