/**
 * main class - Start of program
 * Created by Group 29D on 16/02/2017
 */
public class Main {
    public static void main(String args[]){
        new AuthenticationGUI();
    }
}
